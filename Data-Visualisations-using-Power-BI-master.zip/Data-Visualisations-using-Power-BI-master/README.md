# Visualisation using Power-BI
Data Visualisations in Power BI after data cleansing in power BI


![Data-Visualisations-using-Power-BI](https://github.com/veenapaul/Data-Visualisations-using-Power-BI/blob/master/Customer%20Analysis.png)


![Data-Visualisations-using-Power-BI](https://github.com/veenapaul/Data-Visualisations-using-Power-BI/blob/master/Yearly%20Financial%20Analysis.png)


![Covid-19](https://user-images.githubusercontent.com/58709774/136692327-b0afc57b-d02d-4dc4-8bc6-94293259d860.png)



https://app.powerbi.com/links/5jlaIW6wfU?ctid=d1b36e95-0d50-42e9-958f-b63fa906beaa&pbi_source=linkShare
